// popup/popup.js
document.addEventListener('DOMContentLoaded', init);

function $(sel){ return document.querySelector(sel); }

async function init() {
  const autoToggle = $('#autoToggle');
  const createListBtn = $('#createListBtn');
  const newListName = $('#newListName');
  const listsContainer = $('#listsContainer');
  const listSelect = $('#listSelect');
  const contactsDiv = $('#contacts');
  const sendBtn = $('#sendBtn');
  const endpointInput = $('#endpoint');
  const headerAuth = $('#headerAuth');

  const storage = await getStorage();
  const autoEnabled = storage.autoCaptureEnabled === true;
  autoToggle.checked = autoEnabled;

  const lists = storage.lists || {};
  renderLists(lists);
  populateListSelect(lists);

  autoToggle.addEventListener('change', () => {
    chrome.storage.local.set({ autoCaptureEnabled: autoToggle.checked });
  });

  createListBtn.addEventListener('click', () => {
    const name = newListName.value.trim();
    if (!name) return;
    chrome.storage.local.get(['lists'], (res) => {
      const lists = res.lists || {};
      if (!lists[name]) lists[name] = [];
      chrome.storage.local.set({ lists }, () => {
        renderLists(lists);
        populateListSelect(lists);
        newListName.value = '';
      });
    });
  });

  listSelect.addEventListener('change', () => {
    renderContacts(listSelect.value);
  });

  sendBtn.addEventListener('click', async () => {
    const listName = listSelect.value;
    if (!listName) { alert('Select a list'); return; }
    const endpoint = endpointInput.value.trim();
    chrome.storage.local.get(['lists'], (res) => {
      const lists = res.lists || {};
      const payload = lists[listName] || [];
      if (!endpoint) {
        console.log('Payload to send:', JSON.stringify({ listName, contacts: payload }, null, 2));
        alert('No endpoint provided — payload logged to console.');
        return;
      }
      const headers = {};
      if (headerAuth.value.trim()) headers['Authorization'] = headerAuth.value.trim();
      chrome.runtime.sendMessage({ type: 'SEND_LIST', endpoint, headers, listName }, (reply) => {
        if (reply && reply.ok) {
          alert('Sent! status ' + reply.status);
          // optionally clear list
        } else {
          alert('Send failed: ' + (reply && reply.error) || JSON.stringify(reply));
        }
      });
    });
  });

  function renderLists(lists) {
    listsContainer.innerHTML = '';
    const names = Object.keys(lists);
    if (names.length === 0) listsContainer.innerHTML = '<em>No lists yet</em>';
    names.forEach(n => {
      const d = document.createElement('div');
      d.textContent = `${n} (${lists[n].length})`;
      d.style.padding = '6px 2px';
      d.style.borderBottom = '1px solid #f0f0f0';
      listsContainer.appendChild(d);
    });
  }

  function populateListSelect(lists) {
    listSelect.innerHTML = '';
    Object.keys(lists).forEach(n => {
      const opt = document.createElement('option');
      opt.value = n;
      opt.textContent = n;
      listSelect.appendChild(opt);
    });
    if (listSelect.options.length > 0) {
      listSelect.value = listSelect.options[0].value;
      renderContacts(listSelect.value);
    } else {
      contactsDiv.innerHTML = '<em>No list selected</em>';
    }
  }

  function renderContacts(listName) {
    chrome.storage.local.get(['lists'], (res) => {
      const lists = res.lists || {};
      const items = lists[listName] || [];
      contactsDiv.innerHTML = '';
      if (items.length === 0) contactsDiv.innerHTML = '<em>Empty</em>';
      items.forEach(c => {
        const div = document.createElement('div');
        div.className = 'contact-item';
        div.innerHTML = `<strong>${c.firstName || ''} ${c.lastName || ''}</strong>
          <div>${c.jobTitle || ''} ${c.companyName ? 'at ' + c.companyName : ''}</div>
          <div style="font-size:11px;color:#666">${c.companyDomain || ''} • ${c.profileUrl || ''}</div>`;
        const del = document.createElement('button');
        del.textContent = 'Delete';
        del.addEventListener('click', () => {
          chrome.runtime.sendMessage({ type: 'DELETE_CONTACT', listName, profileUrl: c.profileUrl }, (r) => {
            chrome.storage.local.get(['lists'], (r2) => {
              renderLists(r2.lists || {});
              populateListSelect(r2.lists || {});
            });
          });
        });
        div.appendChild(del);
        contactsDiv.appendChild(div);
      });
    });
  }
}

function getStorage() {
  return new Promise((res) => {
    chrome.runtime.sendMessage({ type: 'GET_STORAGE' }, (reply) => res(reply));
  });
}
