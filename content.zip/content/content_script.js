// content/content_script.js
// Parses LinkedIn/Sales Navigator pages to capture profile URL, name, title, company, domain.
// Injects Save buttons when manual mode is used. Supports auto-capture via storage flag.

(() => {
  const DEBOUNCE_MS = 700;
  let debounceTimer = null;

  function sendMessage(msg) {
    chrome.runtime.sendMessage(msg, (res) => {
      // ignore
    });
  }

  function saveContact(contact, listName = 'default') {
    if (!contact || !contact.profileUrl) return;
    sendMessage({ type: 'SAVE_CONTACT', contact, listName });
  }

  function getCanonicalProfileUrl() {
    const link = document.querySelector('link[rel="canonical"]');
    if (link && link.href && link.href.includes('linkedin.com')) return link.href.split('?')[0];
    if (location.href.includes('/in/')) return location.href.split('?')[0];
    return null;
  }

  function findRealProfileUrlFromNode(node) {
    const anchors = node.querySelectorAll('a[href]');
    for (const a of anchors) {
      const href = a.href;
      if (!href) continue;
      if (/linkedin\.com\/in\//.test(href)) return href.split('?')[0];
    }

    // data attributes often present on SalesNav elements
    const dataAttr = node.querySelector('[data-public-id], [data-publicidentifier], [data-member-id]');
    if (dataAttr) {
      const pub = dataAttr.getAttribute('data-public-id') ||
                  dataAttr.getAttribute('data-publicidentifier') ||
                  dataAttr.getAttribute('data-member-id');
      if (pub && pub.indexOf('.') === -1) {
        return `https://www.linkedin.com/in/${pub}`;
      }
    }
    // fallback: find first anchor pointing to linkedin.com
    for (const a of anchors) {
      if (/linkedin\.com/.test(a.href)) return a.href.split('?')[0];
    }
    return null;
  }

  function parseProfilePage() {
    const profileUrl = getCanonicalProfileUrl();
    if (!profileUrl) return null;

    let fullName = '';
    const nameEl = document.querySelector('.pv-top-card--list li, .pv-top-card--list h1, .text-heading-xlarge, h1');
    if (nameEl) fullName = nameEl.innerText.trim();
    if (!fullName) {
      const meta = document.querySelector('meta[property="og:title"], meta[name="title"]');
      if (meta) fullName = meta.content || '';
    }

    let firstName = '', lastName = '';
    if (fullName) {
      const parts = fullName.split(' ').filter(Boolean);
      firstName = parts.shift() || '';
      lastName = parts.join(' ') || '';
    }

    let title = '';
    const titleEl = document.querySelector('.pv-top-card--headline, .text-body-medium, .text-body-medium.break-words');
    if (titleEl) title = titleEl.innerText.trim();

    let companyName = '';
    // try multiple selectors where current company may appear
    const companyEl = document.querySelector('.pv-entity__secondary-title, a[data-control-name="background_details_company"], .pv-entity__summary-info');
    if (companyEl) companyName = companyEl.innerText.trim();

    let companyDomain = null;
    // contact info modal contains websites; try to find anchor not pointing to linkedin
    const websiteAnchor = Array.from(document.querySelectorAll('a[href^="http"]')).find(a => !a.href.includes('linkedin.com'));
    if (websiteAnchor) {
      try {
        companyDomain = (new URL(websiteAnchor.href)).hostname.replace(/^www\./, '');
      } catch (e) {}
    }

    return {
      profileUrl,
      firstName: firstName || null,
      lastName: lastName || null,
      jobTitle: title || null,
      companyName: companyName || null,
      companyDomain: companyDomain || null,
      capturedAt: new Date().toISOString(),
      source: location.href
    };
  }

  function parseSearchItem(node) {
    const profileUrl = findRealProfileUrlFromNode(node);
    if (!profileUrl) return null;

    let name = '';
    const nameEl = node.querySelector('a[href*="/in/"], .entity-result__title-text, .actor-name, .t-bold');
    if (nameEl) name = nameEl.innerText.trim();
    if (!name) {
      const h = node.querySelector('h3, h2, span');
      if (h) name = h.innerText.trim();
    }
    let firstName = '', lastName = '';
    if (name) {
      const parts = name.split(' ').filter(Boolean);
      firstName = parts.shift() || '';
      lastName = parts.join(' ') || '';
    }

    let jobTitle = '';
    const titleEl = node.querySelector('.entity-result__primary-subtitle, .entity-result__secondary-subtitle, .t-14');
    if (titleEl) jobTitle = titleEl.innerText.trim();

    let companyName = null;
    const companyEl = node.querySelector('.entity-result__secondary-subtitle, .org, .company-name');
    if (companyEl) {
      const text = companyEl.innerText.trim();
      if (text.includes(' at ')) {
        const parts = text.split(' at ');
        jobTitle = jobTitle || parts[0];
        companyName = parts[1];
      } else {
        companyName = text;
      }
    }

    let companyDomain = null;
    const extA = node.querySelector('a[href^="http"]:not([href*="linkedin.com"])');
    if (extA) {
      try {
        companyDomain = (new URL(extA.href)).hostname.replace(/^www\./, '');
      } catch (e) {}
    }

    return {
      profileUrl,
      firstName: firstName || null,
      lastName: lastName || null,
      jobTitle: jobTitle || null,
      companyName: companyName || null,
      companyDomain: companyDomain || null,
      capturedAt: new Date().toISOString(),
      source: location.href
    };
  }

  function addSaveButtonToNode(node) {
    if (node.querySelector('.snav-save-btn')) return;
    const btn = document.createElement('button');
    btn.textContent = 'Save';
    btn.className = 'snav-save-btn';
    btn.style.cssText = 'margin-left:8px;padding:4px 8px;border-radius:4px;border:1px solid #0a66c2;background:white;color:#0a66c2;cursor:pointer;font-size:12px';
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      const contact = parseSearchItem(node) || parseProfilePage();
      if (contact && contact.profileUrl) {
        saveContact(contact, 'default');
        btn.textContent = 'Saved';
        setTimeout(()=> btn.textContent = 'Save', 1200);
      } else {
        btn.textContent = 'Not found';
        setTimeout(()=> btn.textContent = 'Save', 1200);
      }
    });

    // Insert near actions area or append to node
    const actionArea = node.querySelector('.entity-result__actions, .artdeco-entity-lockup__actions') || node;
    try { actionArea.appendChild(btn); } catch (e) { node.appendChild(btn); }
  }

  function scanAndInject() {
    const selectors = [
      '.search-result__occluded-item',
      '.reusable-search__result-container',
      '.entity-result',
      '.artdeco-list__item',
      '.search-result'
    ];
    const nodes = document.querySelectorAll(selectors.join(','));
    if (!nodes || nodes.length === 0) {
      // also try to see if we are on a profile page and inject no buttons
      return;
    }
    nodes.forEach(node => {
      const contact = parseSearchItem(node);
      chrome.storage.local.get(['autoCaptureEnabled'], (res) => {
        if (res.autoCaptureEnabled && contact) {
          saveContact(contact, 'auto-captured');
        } else {
          addSaveButtonToNode(node);
        }
      });
    });
  }

  const observer = new MutationObserver(() => {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      scanAndInject();
    }, DEBOUNCE_MS);
  });

  observer.observe(document.body, { childList: true, subtree: true });
  scanAndInject();

  window.__snavCapture = {
    captureCurrentProfile: () => {
      const contact = parseProfilePage();
      if (contact) saveContact(contact, 'manual');
      return contact;
    },
    captureVisibleResults: () => {
      scanAndInject();
      return true;
    }
  };

})();
